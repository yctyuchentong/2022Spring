package com.example.lab_2_2;


import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Second extends AppCompatActivity {

    List<People> peoples;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        initView();
    }

    private void initView(){
        ListView listView = findViewById(R.id.secondListview);
        intiData();
        //Adpter适配器，让数据和listView结合起来
        PeopleAdpter peopleAdpter = new PeopleAdpter(Second.this,peoples);
        listView.setAdapter(peopleAdpter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                peopleAdpter.setindex(i);
                peopleAdpter.notifyDataSetChanged();
            }
        });
    }

    private void intiData(){
        peoples = new ArrayList<>();
        People people = new People("姓名","于晨彤",R.drawable.header);
        peoples.add(people);

        People people1 = new People("性别","女",R.drawable.header);
        peoples.add(people1);

        People people2 = new People("年龄","20",R.drawable.header);
        peoples.add(people2);

People people3 = new People("居住地","开封",R.drawable.header);
        peoples.add(people3);

        People people4 = new People("邮箱","1731494251@qq.com",R.drawable.header);
        peoples.add(people4);
    }
}
