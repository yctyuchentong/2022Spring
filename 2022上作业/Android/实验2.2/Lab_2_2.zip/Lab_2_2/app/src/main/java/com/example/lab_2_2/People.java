package com.example.lab_2_2;

public class People {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    private String name;
    private String des;
    private int img;

    public People(String name,String des,int img){
        this.name = name;
        this.des = des;
        this.img = img;

    }


}
