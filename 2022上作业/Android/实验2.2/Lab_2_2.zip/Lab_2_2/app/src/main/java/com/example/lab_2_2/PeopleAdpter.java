package com.example.lab_2_2;

import android.content.Context;
import android.graphics.Color;
import android.net.wifi.p2p.WifiP2pManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class PeopleAdpter extends BaseAdapter {

    Context context;
    List<People> people ;
    int index=-1;
    public PeopleAdpter(Context context, List<People> people) {
        this.context = context;
        this.people = people;
    }

    @Override
    //用来获取数据集的数量
    public int getCount() {
        return people.size();
    }

    @Override
    //返回指定position的哪一个item
    public Object getItem(int i) {
        return people.get(i);
    }

    @Override
    //获取下标
    public long getItemId(int i) {
        return i;
    }

    public void setindex(int index){
        this.index = index;
    }
    @Override
    //获取item的布局
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if (view==null){
            viewHolder = new ViewHolder();
            view = View.inflate(context,R.layout.item_people,null);
            viewHolder.pic = view.findViewById(R.id.peopleimg);
            viewHolder.name = view.findViewById(R.id.nametxt);
            viewHolder.des = view.findViewById(R.id.destxt);
            view.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) view.getTag();
        }
        People peo = people.get(i);
        viewHolder.name.setText(peo.getName());
        viewHolder.des.setText(peo.getDes());
        viewHolder.pic.setImageResource(peo.getImg());

        //设置背景
        if (i%2==0){
            view.setBackgroundColor(context.getResources().getColor(R.color.color1));
        }else {
            view.setBackgroundColor(context.getResources().getColor(R.color.color2));
        }
        if(i==index){
            view.setBackgroundColor(context.getResources().getColor(R.color.click));
        }
        return view;
    }
    //静态内部类，没有对外部类有引用，避免内存泄露
    static class ViewHolder{
        ImageView pic;
        TextView name;
        TextView des;
    }
}
